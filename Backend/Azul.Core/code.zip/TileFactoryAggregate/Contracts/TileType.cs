﻿namespace Azul.Core.TileFactoryAggregate.Contracts;

public enum TileType
{
    StartingTile = 0,
    PlainBlue = 11,
    YellowRed = 12,
    PlainRed = 13,
    BlackBlue = 14,
    WhiteTurquoise = 15,
}