﻿namespace Azul.Core.Util;

public class DataNotFoundException : Exception
{
}