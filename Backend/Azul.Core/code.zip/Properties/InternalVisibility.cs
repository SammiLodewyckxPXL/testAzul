﻿using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("Azul.Bootstrapper")]
[assembly: InternalsVisibleTo("Azul.Api.Tests")]
[assembly: InternalsVisibleTo("Azul.Core.Tests")]